let dados = JSON.parse(localStorage.getItem("dados")) || [];

function salvar(){
    localStorage.setItem("dados", JSON.stringify(dados));
}

function mostrar(){

    let lista = document.getElementById("lista");
    lista.innerHTML = "";

    dados.forEach((nome,index)=>{

        lista.innerHTML += `
        <li>
            ${nome}
            <div class="actions">
                <button class="edit" onclick="editar(${index})">Editar</button>
                <button class="delete" onclick="deletar(${index})">Excluir</button>
            </div>
        </li>
        `;

    });

    // contador de nomes
    document.getElementById("contador").innerText = "Total: " + dados.length;

}

function adicionar(){

    let input = document.getElementById("nome");
    let nome = input.value.trim();

    if(nome === "") return;

    dados.push(nome);

    input.value = "";
    input.focus();

    salvar();
    mostrar();

}

function editar(index){

    let novo = prompt("Editar nome:", dados[index]);

    if(novo){
        dados[index] = novo;
        salvar();
        mostrar();
    }

}

function deletar(index){

    dados.splice(index,1);

    salvar();
    mostrar();

}

function limparTudo(){

    if(confirm("Deseja apagar todos os nomes?")){
        dados = [];
        salvar();
        mostrar();
    }

}

// adicionar com ENTER
document.getElementById("nome").addEventListener("keypress", function(event){
    if(event.key === "Enter"){
        adicionar();
    }
});

mostrar();