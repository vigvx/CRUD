const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json()); // substitui body-parser

// Conexão com o MySQL
const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "SUA_SENHA", // coloque sua senha aqui
    database: "crud"
});

// Testa conexão
db.connect(err => {
    if (err) {
        console.error("Erro ao conectar ao MySQL:", err.message);
        process.exit(1); // encerra se não conseguir conectar
    } else {
        console.log("Conectado ao MySQL!");
    }
});

// Listar nomes (Read)
app.get("/nomes", (req, res) => {
    db.query("SELECT * FROM nomes", (err, results) => {
        if (err) {
            console.error("Erro ao listar nomes:", err);
            return res.status(500).json({ error: "Erro ao listar nomes" });
        }
        res.json(results);
    });
});

// Adicionar nome (Create)
app.post("/nomes", (req, res) => {
    const { nome } = req.body;
    if (!nome || nome.trim() === "") {
        return res.status(400).json({ error: "Nome é obrigatório" });
    }

    db.query("INSERT INTO nomes(nome) VALUES(?)", [nome.trim()], (err, results) => {
        if (err) {
            console.error("Erro ao adicionar nome:", err);
            return res.status(500).json({ error: "Erro ao adicionar nome" });
        }
        res.json({ id: results.insertId, nome: nome.trim() });
    });
});

// Editar nome (Update)
app.put("/nomes/:id", (req, res) => {
    const { nome } = req.body;
    const { id } = req.params;

    if (!nome || nome.trim() === "") {
        return res.status(400).json({ error: "Nome é obrigatório" });
    }

    db.query("UPDATE nomes SET nome=? WHERE id=?", [nome.trim(), id], (err, results) => {
        if (err) {
            console.error("Erro ao editar nome:", err);
            return res.status(500).json({ error: "Erro ao editar nome" });
        }
        res.sendStatus(200);
    });
});

// Deletar nome (Delete)
app.delete("/nomes/:id", (req, res) => {
    const { id } = req.params;

    db.query("DELETE FROM nomes WHERE id=?", [id], (err, results) => {
        if (err) {
            console.error("Erro ao deletar nome:", err);
            return res.status(500).json({ error: "Erro ao deletar nome" });
        }
        res.sendStatus(200);
    });
});

// Iniciar servidor
const PORT = 3000;
app.listen(PORT, () => console.log(`Servidor rodando na porta ${PORT}`));